<?php

include ('dbcon.php');

?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="icon" type="image/x-icon" href="techgeek.png">
</head>
<body>

<div class="background-image">
  <div class="form-wrapper">
    
      <form action="login.php" method="post">
      <h3>Login here</h3>
    
      <div class="form-item">
          <label for="username">Username:</label>
          <input type="text" name="username" id="username" required><br>
      </div>
      
      <div class="form-item">
          <label for="password">Password:</label>
          <input type="password" name="password" id="password" required><br>
      </div>

      <div class="button-panel">
      <input type="submit" class="button" title="Log In" name="login" value="Login"></input>
      </div>

      </form>

      <div class="reminder">
      <p>Not a member? <a href="./home/user.php">Visit Our Page</a></p>
    </div>
    
  </div>
</div>
</body>
</html>












