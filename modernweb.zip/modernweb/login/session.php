<?php

//start the session
session_start();

// Check if the user is logged in
function isUserLoggedIn() {
    return isset($_SESSION['user_name']) && $_SESSION['user_role'] == 'user';
}

// Check if the admin is logged in
function isAdminLoggedIn() {
    return isset($_SESSION['user_name']) && $_SESSION['user_role'] == 'admin';
}

// Function to set a user or admin as logged in
function loginUser($user_name, $user_role) {
    $_SESSION['user_name'] = $user_name;
    $_SESSION['user_role'] = $user_role;
}

// Function to log the user or admin out
function logoutUser() {
    // Unset all session variables
    $_SESSION = array();

    // Destroy the session
    session_destroy();
}
?>

