<?php
include('dbcon.php'); // Include your database connection file

// Get input data from the signup form
$user_name = $_POST['username'];
$password = $_POST['password'];

if (empty($user_name) || empty($password)) {
    // Registration failed - username or password not provided
    echo "Invalid username or password. Please provide both.";
} else {
    // Check if the username already exists in the database
    $check_query = "SELECT * FROM users WHERE username = '$user_name'";
    $result = $con->query($check_query);

    if ($result->num_rows > 0) {
        // Username already exists
        echo "Username already exists. Please choose a different username.";
    } else {
        // Assign role based on username
        $user_role = (strpos($user_name, 'admin') === 0) ? 'admin' : 'user';

        // Insert the user into the 'users' table with the plain text password
        $insert_query = "INSERT INTO users (username, password, role) VALUES ('$user_name', '$password', '$user_role')";

        if ($con->query($insert_query) === TRUE) {
            // User registered successfully
            header("Location: index.php"); // Redirect to the login page
        } else {
            echo "Error: " . $insert_query . "<br>" . $con->error;
        }
    }
}

// Close the database connection
$con->close();
?>
