<?php
include('dbcon.php');
include('session.php');

// Get input data from the login form
$user_name = $_POST['username'];
$password = $_POST['password']; 

if (empty($user_name) || empty($password)) {
    // Authentication failed - username or password not provided
    echo "Invalid username or password. Please provide both.";
} else {
    // Check if the username exists in the database
    $check_query = "SELECT * FROM users WHERE username = ?";
    $stmt = $con->prepare($check_query);
    $stmt->bind_param("s", $user_name);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // User exists, fetch the role and password
        $row = $result->fetch_assoc();
        $user_role = $row['role'];
        $stored_password = $row['password'];

        // Verify the password
        if ($password == $stored_password) {
            // Password matches, set the session
            loginUser($user_name, $user_role);

            // Redirect the user to the appropriate page
            if ($user_role == 'admin') {
                header("Location: ../admin/admin.php");
            } elseif ($user_role == 'user') {
                header("Location: ../home/user.php");
            }
            exit(); // Terminate script after redirection
        } else {
            // Password does not match
            echo "Invalid username or password. Please try again.";
        }
    } else {
        // User doesn't exist, redirect to the signup page or display an error message
        echo "User does not exist. Please sign up.";
        // header("Location: signup.php");
    }
}

// Close the database connection
$stmt->close();
$con->close();
?>
