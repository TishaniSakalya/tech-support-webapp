<?php
// Start the session
session_start();

// Include session.php for the loginUser and logoutUser functions
include('../session.php');

// Check if the user is logged in
if (isset($_SESSION['user_name'])) {
    // Call the logoutUser function from session.php
    logoutUser();
}

// Redirect the user to the login page or any other appropriate page
header("Location: index.php");
?>


