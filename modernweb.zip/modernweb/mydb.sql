CREATE DATABASE IF NOT EXISTS `mydb`;

USE `mydb`;

CREATE TABLE IF NOT EXISTS `users` (
    id INT AUTO_INCREMENT PRIMARY KEY,
    `username` varchar(50) NOT NULL,
    `password` varchar(50) NOT NULL,
    `role` varchar(20) NOT NULL
) ENGINE=InnoDB;

INSERT INTO `users` (`username`,`password`, `role`) VALUES
('nibm','nibm','user'),
('admin','123','admin');


CREATE TABLE IF NOT EXISTS `customer` (
    `name` varchar(50) NOT NULL,
    `contact` char(10) NOT NULL,
    `location` char(30)
) ENGINE=InnoDB;

INSERT INTO `customer` (`name`, `contact`, `location`)
VALUES ('Liam', '0761234567', 'Colombo'),
       ('Harry', '0112345678', 'Kandy');


CREATE TABLE IF NOT EXISTS `service_provider`(
    `name` varchar(50) NOT NULL,
    `contact` char(10) NOT NULL,
    `location` char(30) NOT NULL
) ENGINE=InnoDB;

INSERT INTO `service_provider` VALUES
('Maharaja Company','0761234567','Galle'),
('CJ','0112345678','Kandy'),
('TechSoft Inc.','0112674538','Colombo'),
('CodeCrafters','0783524233','Jaffna'),
('Tech Wizards','0772452424','Matara'),
('Tech Hardware', '0712345678', 'Colombo'),
('Hardware Experts', '0771234567', 'Kandy'),
('Tech Solutions', '0767654321', 'Galle'),
('Network Pro', '0712345678', 'Colombo'),
('Network Wizards', '0771234567', 'Kandy'),
('ConnectTech', '0767654321', 'Galle'),
('DataTech', '0713335555', 'Colombo'),
('RecoverAll', '0778889999', 'Kandy'),
('DataRescue', '0761113333', 'Galle'),
('CyberGuard', '0715554444', 'Colombo'),
('SecureNet', '0776668888', 'Kandy'),
('ShieldTech', '0767779999', 'Galle');


CREATE TABLE IF NOT EXISTS `software`(
    `name` varchar(50) NOT NULL,
    `service1` varchar(50) NOT NULL,
    `description1` varchar(100) NOT NULL,
    `pricing1` char(10) NOT NULL,
    `service2` varchar(50) NOT NULL,
    `description2` varchar(100) NOT NULL,
    `pricing2` char(10) NOT NULL,
    `service3` varchar(50) NOT NULL,
    `description3` varchar(100) NOT NULL,
    `pricing3` char(10) NOT NULL
) ENGINE=InnoDB;

INSERT INTO `software` (`name`, `service1`, `description1`, `pricing1`, `service2`, `description2`, `pricing2`, `service3`, `description3`, `pricing3`)
VALUES
('TechSoft Inc.', 'Data Analytics', 'Advanced data analysis for business insights', '3000', 'Web Development', 'Custom website and web app development', '5000', 'Mobile App Development', 'iOS and Android mobile app development', '4000'),
('CodeCrafters', 'Cloud Solutions', 'Cloud infrastructure setup and management', '2500', 'Software Security', 'Enhanced software security and threat detection', '3500', 'Database Administration', 'Database design and administration services', '2000'),
('Tech Wizards', 'AI Solutions', 'AI and machine learning solutions', '4000', 'E-commerce Solutions', 'Custom e-commerce website development', '3500', 'Data Visualization', 'Interactive data visualization services', '3000');

CREATE TABLE IF NOT EXISTS `hardware`(
    `name` varchar(50) NOT NULL,
    `service1` varchar(50) NOT NULL,
    `description1` varchar(100) NOT NULL,
    `pricing1` char(10) NOT NULL,
    `service2` varchar(50) NOT NULL,
    `description2` varchar(100) NOT NULL,
    `pricing2` char(10) NOT NULL,
    `service3` varchar(50) NOT NULL,
    `description3` varchar(100) NOT NULL,
    `pricing3` char(10) NOT NULL
) ENGINE=InnoDB;

INSERT INTO `hardware` (`name`, `service1`, `description1`, `pricing1`, `service2`, `description2`, `pricing2`, `service3`, `description3`, `pricing3`)
VALUES
('Tech Hardware', 'Laptop Repair', 'Laptop repair and troubleshooting', '1500', 'Desktop Repair', 'Desktop computer repair services', '1800', 'Hardware Upgrades', 'Hardware component upgrades', '1200'),
('Hardware Experts', 'Printer Repair', 'Printer repair and maintenance services', '1400', 'Network Setup', 'Home and office network setup', '2000', 'Hardware Sales', 'Quality hardware sales and products', '1300'),
('Tech Solutions', 'Data Recovery', 'Data recovery from storage devices', '1600', 'Server Maintenance', 'Server and data center maintenance', '1900', 'Hardware Installation', 'Hardware and server installation', '1700');

CREATE TABLE IF NOT EXISTS `network`(
    `name` varchar(50) NOT NULL,
    `service1` varchar(50) NOT NULL,
    `description1` varchar(100) NOT NULL,
    `pricing1` char(10) NOT NULL,
    `service2` varchar(50) NOT NULL,
    `description2` varchar(100) NOT NULL,
    `pricing2` char(10) NOT NULL,
    `service3` varchar(50) NOT NULL,
    `description3` varchar(100) NOT NULL,
    `pricing3` char(10) NOT NULL
) ENGINE=InnoDB;

INSERT INTO `network` (`name`, `service1`, `description1`, `pricing1`, `service2`, `description2`, `pricing2`, `service3`, `description3`, `pricing3`)
VALUES
('Network Pro', 'Wireless Network Setup', 'Setting up and configuring wireless networks', '1200', 'Network Troubleshooting', 'Troubleshooting network issues', '1500', 'Network Security', 'Enhancing network security', '1400'),
('Network Wizards', 'Router Configuration', 'Router setup and configuration services', '1300', 'VPN Setup', 'Virtual Private Network (VPN) setup', '1700', 'Network Monitoring', 'Real-time network monitoring services', '1600'),
('ConnectTech', 'LAN Setup', 'Local Area Network (LAN) setup', '1100', 'Firewall Installation', 'Firewall setup and installation', '1800', 'Cabling Services', 'Network cabling and infrastructure', '1900');

CREATE TABLE IF NOT EXISTS `data_support`(
    `name` varchar(50) NOT NULL,
    `service1` varchar(50) NOT NULL,
    `description1` varchar(100) NOT NULL,
    `pricing1` char(10) NOT NULL,
    `service2` varchar(50) NOT NULL,
    `description2` varchar(100) NOT NULL,
    `pricing2` char(10) NOT NULL,
    `service3` varchar(50) NOT NULL,
    `description3` varchar(100) NOT NULL,
    `pricing3` char(10) NOT NULL
) ENGINE=InnoDB;

INSERT INTO `data_support` (`name`, `service1`, `description1`, `pricing1`, `service2`, `description2`, `pricing2`, `service3`, `description3`, `pricing3`)
VALUES
('DataTech', 'Hard Drive Recovery', 'Professional hard drive data recovery', '2500', 'SSD Data Recovery', 'Specialized SSD data recovery', '3000', 'File Repair', 'Data file repair services', '2000'),
('RecoverAll', 'Memory Card Recovery', 'Recover data from memory cards', '1800', 'RAID Data Recovery', 'RAID array data recovery', '3500', 'Mobile Data Recovery', 'Data recovery from mobile devices', '2200'),
('DataRescue', 'Email Data Recovery', 'Recover lost email data', '2000', 'Database Recovery', 'Database data recovery services', '3200', 'External Drive Recovery', 'Recover data from external drives', '2800');

CREATE TABLE IF NOT EXISTS `cyber`(
    `name` varchar(50) NOT NULL,
    `service1` varchar(50) NOT NULL,
    `description1` varchar(100) NOT NULL,
    `pricing1` char(10) NOT NULL,
    `service2` varchar(50) NOT NULL,
    `description2` varchar(100) NOT NULL,
    `pricing2` char(10) NOT NULL,
    `service3` varchar(50) NOT NULL,
    `description3` varchar(100) NOT NULL,
    `pricing3` char(10) NOT NULL
) ENGINE=InnoDB;

INSERT INTO `cyber` (`name`, `service1`, `description1`, `pricing1`, `service2`, `description2`, `pricing2`, `service3`, `description3`, `pricing3`)
VALUES
('CyberGuard', 'Network Security', 'Protect your network from cyber threats', '3000', 'Data Encryption', 'Secure your data through encryption', '2500', 'Penetration Testing', 'Test your security with penetration testing', '4000'),
('SecureNet', 'Firewall Management', 'Firewall configuration and management', '2700', 'Virus Protection', 'Virus and malware protection services', '2200', 'Security Consultation', 'Cyber security consultation services', '3500'),
('ShieldTech', 'Distributed Denial of Service (DDoS) Protection', 'Protect against DDoS attacks', '3200', 'Cyber Threat Analysis', 'Analyze and respond to cyber threats', '2800', 'Incident Response', 'Cyber incident response services', '3800');

CREATE TABLE IF NOT EXISTS `payment`(
    `name` varchar(50) NOT NULL,
    `payment` char(10) NOT NULL
) ENGINE=InnoDB;

INSERT INTO `payment` (`name`, `payment`)
VALUES
('Liam', '1000'),
('Harry', '500'),
('Ella', '750');


CREATE TABLE contact (
    `name` VARCHAR(255) NOT NULL,
    `email` CHAR(255) NOT NULL,
    `message` TEXT NOT NULL
) ENGINE=InnoDB;




