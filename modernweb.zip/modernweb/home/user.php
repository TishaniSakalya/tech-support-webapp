<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="common.css">
    <link rel="icon" type="image/x-icon" href="techgeek.png"> 
    <title>TechGeeks</title>
</head>
<body>

    <?php
    include('../session.php');

    // Now you can access the user_name
    $user_name = $_SESSION['user_name'];

    ?>

    <script type="text/javascript">
        // Display a pop-up message
        alert("Welcome user <?php echo $_SESSION['user_name']; ?>!");
    </script>


    
    <div class="background-image">
        
        <div class="navbar">
            <ul>
                <li><a href="../home/user.php">Home</a></li>
                <li><a href="../customer/customer.php">Services</a></li>
                <li><a href="../contact/contact.html">Contact</a></li>
                <li><a href="../help/help.php">Help</a></li>
            </ul>
            <div class="user-section">
                <div class="user-icon" id="user-icon"><a href="../logout.php">Log Out</a></div>
                        <div class="user-options" id="user-options">
                        </div>
                        
                </div>

                <script type="text/javascript">
                var userIcon = document.getElementById("user-icon");
                var userOptions = document.getElementById("user-options");

                userIcon.addEventListener("click", function () {
                    userOptions.style.display = (userOptions.style.display === "block") ? "none" : "block";
                });
                </script>


            </div>

            <div class="center-content">        
                    <h1 class="slogan">Tech help, Simplified.</h1>
            </div>

            <?php 
                include('dbcon.php');

                $sql1 = "SELECT COUNT(*) AS user_count FROM `users`";
                $sql2 = "SELECT COUNT(*) AS customer_count FROM `customer`";
                $sql3 = "SELECT COUNT(*) AS service_provider_count FROM `service_provider`";
                $sql4 = "SELECT COUNT(*) AS transaction_count FROM `payment`";
                $sql6 = "SELECT COUNT(*) AS contact_count FROM `contact`";

                $result1 = $con->query($sql1);
                $result2 = $con->query($sql2);
                $result3 = $con->query($sql3);
                $result4 = $con->query($sql4);
                $result6 = $con->query($sql6);

                if ($result1 && $result2 &&  $result3 && $result4 && $result6) {
                    $row1 = $result1->fetch_assoc();
                    $row2 = $result2->fetch_assoc();
                    $row3 = $result3->fetch_assoc();
                    $row4 = $result4->fetch_assoc();
                    $row6 = $result6->fetch_assoc();
                ?>

                <div class="highlight-container">

                    <div class="highlight-box">
                        There are currently <?php echo $row1['user_count']; ?> logged-in users
                    </div>

                    <div class="highlight-box">
                        <?php echo $row1['user_count']; ?> customers are registered
                    </div>

                    <div class="highlight-box">
                        We have <?php echo $row3['service_provider_count']; ?> registered service providers
                    </div>
                    <div class="highlight-box">
                        There have been <?php echo $row4['transaction_count']; ?> transactions
                    </div>
                    <div class="highlight-box">
                        <?php echo $row6['contact_count']; ?> users have reached out to us
                    </div>
                </div>

                <?php

                } else {
                    echo "Error: " . $con->error;
                }

                // Close the database connection
                $con->close();
                ?>
        </div>
    </div>



    <!-- Footer -->
    <footer>
        <p>&copy; TechGeeks 2024. All Rights Reserved.</p>
    </footer>
</body>
</html>






























