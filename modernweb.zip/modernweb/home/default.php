<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="common.css"> 
    <style>
        
        .logout-button {
            position: fixed;
            top:8px;
            right: 8px;
            background-color: #007BFF;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        .logout-button a {
            text-decoration: none;
            color: white;
        }

        .highlight-container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            height: 50vh; /* 50% of the viewport height */
        }

        .highlight-box {
            background-color: rgb(0, 0, 0);
            color: white;
            padding: 5px;
            margin: 5px;
            border-radius: 5px;
            text-align: center;
            width: 150px;
        }
    </style>
    <title>TechGeeks</title>
</head>
<body>

    <script type="text/javascript">
        // Display a pop-up message
        alert("Welcome user!");
    </script>

    <div class="background-image">
        
        <div class="navbar">
            <ul>
                <li><a href="../home/default.php">Home</a></li>
                <li><a href="../customer/customer.php" onclick="return showErrorMessage()">Services</a></li>
                <li><a href="../contact/contact.html">Contact</a></li>
                <li><a href="../help/help.php">Help</a></li>
            </ul>
            <div class="user-section">
                <div class="user-icon" id="user-icon"></div>
                        <div class="user-options" id="user-options">
                        </div>
                        
                </div>
            </div>
            <div class="logout-button">
                <?php
                echo '<a href="../index.php">Log In</a>';
                ?>
            </div>


            <div class="center-content">        
                     <h1 class="slogan">Tech Help, Simplified.</h1>
            </div>


            <?php 
                include('dbcon.php');

                $sql1 = "SELECT COUNT(*) AS user_count FROM `users`";
                $sql2 = "SELECT COUNT(*) AS customer_count FROM `customer`";
                $sql3 = "SELECT COUNT(*) AS service_provider_count FROM `service_provider`";
                $sql4 = "SELECT COUNT(*) AS transaction_count FROM `payment`";
                $sql6 = "SELECT COUNT(*) AS contact_count FROM `contact`";

                $result1 = $con->query($sql1);
                $result2 = $con->query($sql2);
                $result3 = $con->query($sql3);
                $result4 = $con->query($sql4);
                $result6 = $con->query($sql6);

                if ($result1 && $result2 && $result3 && $result4 && $result6) {
                    $row1 = $result1->fetch_assoc();
                    $row2 = $result2->fetch_assoc();
                    $row3 = $result3->fetch_assoc();
                    $row4 = $result4->fetch_assoc();
                    $row6 = $result6->fetch_assoc();
                ?>

                <div class="highlight-container">

                    <div class="highlight-box">
                        There are currently <?php echo $row1['user_count']; ?> logged-in users
                    </div>
                    <div class="highlight-box">
                        <?php echo $row2['customer_count']; ?> customers are registered
                    </div>
                    <div class="highlight-box">
                        We have <?php echo $row3['service_provider_count']; ?> registered service providers
                    </div>
                    <div class="highlight-box">
                        There have been <?php echo $row4['transaction_count']; ?> transactions
                    </div>
                    <div class="highlight-box">
                        <?php echo $row6['contact_count']; ?> users have reached out to us
                    </div>
                </div>

                <?php

                } else {
                    echo "Error: " . $con->error;
                }

                // Close the database connection
                $con->close();
                ?>

        </div>

           
    </div>

    <script>
    function showErrorMessage() {
        alert("You need to log in to access this page.");
        return false; 
    }
    </script>

    <!-- Footer -->
    <footer>
        <p>&copy; TechGeeks 2024. All Rights Reserved.</p>
    </footer>
</body>
</html>




