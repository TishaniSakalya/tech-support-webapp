<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: center;
            color: black; /* Set the text color to black */
        }


        th {
            background-color: #f2f2f2;
        }

        a {
            color: black; /* Set the link color to black */
            text-decoration: none;
        }


        /* style for Log Out button */
        .logout-button {
            position: fixed;
            top:8px;
            right: 8px;
            background-color: #007BFF;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        .logout-button a {
            text-decoration: none;
            color: white;
        }

        /* Set background image */
        .background-image {
            background-image: url('tech4.jpg');
            background-size: cover;
            background-position: center;
            min-height: 100vh;
            position: relative;
            color: #fff;
            text-align: center; /* Center content horizontally and vertically */
        }


        * User section */
        .user-section {
            display: flex;
            align-items: center;
        }

        .user-icon {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
        }

        .user-menu {
            display: none;
            position: absolute;
            top: 30px;
            right: 10px;
            background-color: #f9f9f9;
            padding: 10px;
            border: 1px solid #ddd;
        }

        .user-options {
            display: none;
            flex-direction: column;
            position: absolute;
            top: 30px;
            right: 0;
            background: #333;
            z-index: 1;
        }

        .user-options a {
            color: #ffffff;
            text-decoration: none;
            padding: 5px 10px;
        }

        /* Footer */
        footer {
            text-align: center;
            background: #333;
            padding: 10px 0;
        }

        footer p {
            color: #fff;
            font-size: 14px;
        }


    </style>
    <link rel="icon" type="image/x-icon" href="techgeek.png">
</head>
<body>

<div class="background-image">

    <?php
    session_start(); // Make sure to start the session

    $user_name = $_SESSION['user_name'];

    if (empty($user_name) || strpos($user_name, 'admin') !== 0) {
        // If user_name is empty or doesn't start with 'admin'
        echo '<script>alert("Access denied. You do not have permission to access this page.");</script>';
        exit; // Stop further execution of the script
    }
    ?>


    <script type="text/javascript">
        // Display a pop-up message
        alert("Welcome, <?php echo $_SESSION['user_name']; ?>!");
    </script>

    <div class="logout-button">
        <?php
         echo '<a href="../logout.php">Log Out</a>';
        ?>
    </div>

    <script type="text/javascript">
    var userIcon = document.getElementById("user-icon");
    var userOptions = document.getElementById("user-options");

    userIcon.addEventListener("click", function () {
        userOptions.style.display = (userOptions.style.display === "block") ? "none" : "block";
    });
    </script>


    <span style=color:blue>User Management: </span>
        <a href="add_user.html">Add User</a>
        <a href="edit_user.html">Edit User</a>
        <a href="remove_user.html">Remove User</a>
        <a href="view_user.html">View User</a>


    <h3 style=color:crimson>Users List</h3>
    <?php
    include('dbcon.php');

    // Query to retrieve all users from the 'users' table
    $sql = "SELECT DISTINCT username, role FROM users";
    $result = $con->query($sql);

    if ($result->num_rows > 0) {
        echo "<table>
                <tr>
                    <th>Username</th>
                    <th>Role</th>
                </tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["username"] . "</td>
                    <td>" . $row["role"] . "</td>
                </tr>";
        }
        echo "</table>";
    } else {
        echo "No users found.";
    }

    $con->close();
    ?>


    <hr>

        <span style=color:blue>Customer Management: </span>
            <a href="add_customer.html">Add Customer</a>
            <a href="edit_customer.html">Edit Customer</a>
            <a href="remove_customer.html">Remove Customer</a>
            <a href="view_customer.html">View Customer</a>


    <h3 style=color:crimson>Customers List</h3>
    
    <?php
    include('dbcon.php');

    // Query to retrieve all customers from the 'customers' table
    $sql = "SELECT DISTINCT name,contact FROM customer";
    $result = $con->query($sql);

    if ($result->num_rows > 0) {
        echo "<table>
                <tr>
                    <th>Name</th>
                    <th>Contact</th>
                </tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["name"] . "</td>
                    <td>" . $row["contact"] . "</td>
                </tr>";
        }
        echo "</table>";
    } else {
        echo "No customers found.";
    }

    $con->close();
    ?>

    
</div>

    <!-- Footer -->
    <footer>
        <p>&copy; TechGeeks 2024. All Rights Reserved.</p>
    </footer>
    
</body>
</html>

