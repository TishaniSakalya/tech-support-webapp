<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
    /* Set background image */
        .background-image {
            background-image: url('tech4.jpg');
            background-size: cover;
            background-position: center;
            min-height: 100vh;
            position: relative;
            color: #fff;
            text-align: center; /* Center content horizontally and vertically */
        }

        /* style for Log Out button */
        .logout-button {
            position: fixed;
            top:8px;
            right: 8px;
            background-color: #007BFF;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        .logout-button a {
            text-decoration: none;
            color: white;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        .container {
            display: flex;
            height: 100vh;
        }

        .sidebar {
            width: 250px;
            background-color: #E898C6;
            color: #E898C6;
            padding: 20px;
            height: 100%; 
        }

        .sidebar a {
            display: block;
            color: #fff;
            text-decoration: none;
            padding: 10px 0;
        }

        .dropdown-content {
            display: none;
            padding-left: 15px;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Style for section titles */
        .section-title {
            color: #007BFF;
            font-weight: bold;
        }

        .tables {
            flex: 1; /* Take up the remaining width */
            padding: 20px;
            background-color: white;
            color: #000;
        }

        .tables h3 {
            color: crimson;
        }

        .tables table {
            border-collapse: collapse;
            width: 100%;
        }

        .tables table, .tables th, .tables td {
            border: 1px solid #ddd;
        }

        .tables th, .tables td {
            padding: 8px;
            text-align: left;
        }

        .tables th {
            background-color: #f2f2f2;
        }

    </style>
    <link rel="icon" type="image/x-icon" href="techgeek.png">
</head>
<body>
<div class="background-image">

    <?php
    session_start(); // Make sure to start the session

    $user_name = $_SESSION['user_name'];

    if (empty($user_name) || strpos($user_name, 'admin') !== 0) {
        // If user_name is empty or doesn't start with 'admin'
        echo '<script>alert("Access denied. You do not have permission to access this page.");</script>';
        exit; // Stop further execution of the script
    }
    ?>


    <script type="text/javascript">
        // Display a pop-up message
        alert("Welcome, <?php echo $_SESSION['user_name']; ?>!");
    </script>

    <div class="logout-button">
        <?php
         echo '<a href="../logout.php">Log Out</a>';
        ?>
    </div>

    <script type="text/javascript">
    var userIcon = document.getElementById("user-icon");
    var userOptions = document.getElementById("user-options");

    userIcon.addEventListener("click", function () {
        userOptions.style.display = (userOptions.style.display === "block") ? "none" : "block";
    });
    </script>

    <div class="container">
        <div class="sidebar">
            <div class="dropdown">
                <span class="section-title">
                    <a href="javascript:void(0);" onclick="toggleDropdown('userDropdown')">User Management</a>
                </span>

                <div class="dropdown-content" id="userDropdown">
                    <a href="add_user.html">Add User</a>
                    <a href="edit_user.html">Edit User</a>
                    <a href="remove_user.html">Remove User</a>
                    <a href="view_user.html">View User</a>
                </div>
            </div>
            <div class="dropdown">
                <span class="section-title">
                    <a href="javascript:void(0);" onclick="toggleDropdown('userDropdown')">Customer Management</a>
                </span>
                
                <div class="dropdown-content" id="userDropdown">
                    <a href="add_customer.html">Add Customer</a>
                    <a href="edit_customer.html">Edit Customer</a>
                    <a href="remove_customer.html">Remove Customer</a>
                    <a href="view_customer.html">View Customer</a>
                </div>
            </div>
           
        </div>

        <div class="tables">
            <h3>Users List</h3>
            <?php
            // PHP code for displaying the Users List table
            include('dbcon.php');

            $sql = "SELECT DISTINCT username, role FROM users";
            $result = $con->query($sql);

            if ($result->num_rows > 0) {
                echo "<table>
                        <tr>
                            <th>Username</th>
                            <th>Role</th>
                        </tr>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . $row["username"] . "</td>
                            <td>" . $row["role"] . "</td>
                        </tr>";
                }
                echo "</table>";
            } else {
                echo "No users found.";
            }

            $con->close();
            ?>

            
            <h3>Customers List</h3>
            <?php
            // PHP code for displaying the Customers List table
            include('dbcon.php');

            $sql = "SELECT DISTINCT name, contact FROM customer";
            $result = $con->query($sql);

            if ($result->num_rows > 0) {
                echo "<table>
                        <tr>
                            <th>Name</th>
                            <th>Contact</th>
                        </tr>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . $row["name"] . "</td>
                            <td>" . $row["contact"] . "</td>
                        </tr>";
                }
                echo "</table>";
            } else {
                echo "No customers found.";
            }

            $con->close();
            ?>
        </div>
    </div>

    <script>
        function toggleDropdown(dropdownId) {
            var dropdown = document.getElementById(dropdownId);
            if (dropdown.style.display === 'block') {
                dropdown.style.display = 'none';
            } else {
                dropdown.style display = 'block';
            }
        }
    </script>
</div>
</body>
</html>

