<?php
include ('dbcon.php');

// Retrieve the list of usernames and roles to add, and split them into arrays
$usernames_to_add = explode(',', $_POST['usernames_to_add']);
$roles_to_add = explode(',', $_POST['roles_to_add']);

// Initialize an array to store errors
$errors = [];

// Check if the number of usernames and roles match
if (count($usernames_to_add) !== count($roles_to_add)) {
    echo "The number of usernames and roles must match.";
    exit;
}

for ($i = 0; $i < count($usernames_to_add); $i++) {
    $username_to_add = trim($usernames_to_add[$i]);
    $role_to_add = trim($roles_to_add[$i]);

    $username_to_add = $con->real_escape_string($username_to_add);
    $role_to_add = $con->real_escape_string($role_to_add);

    // Add the user into the 'users' table
    $sql = "INSERT INTO users (username, role) VALUES ('$username_to_add', '$role_to_add')";

    if ($con->query($sql) !== TRUE) {
        // Error handling: If a user addition fails, add it to the errors array
        $errors[] = "Error adding user '$username_to_add': " . $con->error;
    }
}

// Check if any errors occurred during the addition process
if (count($errors) === 0) {
    // All users added successfully
    header("Location: admin.php");
} else {
    // Handle errors (you can display them or log them)
    foreach ($errors as $error) {
        echo $error . "<br>";
    }
}

// Close the database connection
$con->close();
?>




