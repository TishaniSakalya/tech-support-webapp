<?php
include ('dbcon.php');

// Retrieve the list of names and contact information to add, and split them into arrays
$names_to_add = explode(',', $_POST['names_to_add']);
$contacts_to_add = explode(',', $_POST['contacts_to_add']);

// Initialize an array to store errors
$errors = [];

// Check if the number of names and contact information match
if (count($names_to_add) !== count($contacts_to_add)) {
    echo "The number of names and contact information must match.";
    exit;
}

for ($i = 0; $i < count($names_to_add); $i++) {
    $name_to_add = trim($names_to_add[$i]);
    $contact_to_add = trim($contacts_to_add[$i]);

    $name_to_add = $con->real_escape_string($name_to_add);
    $contact_to_add = $con->real_escape_string($contact_to_add);

    // Add the customer into the 'customer' table
    $sql = "INSERT INTO customer (name, contact, location)
            VALUES ('$name_to_add', '$contact_to_add', NULL)";

    if ($con->query($sql) !== TRUE) {
        // Error handling: If a customer addition fails, add it to the errors array
        $errors[] = "Error adding customer '$name_to_add': " . $con->error;
    }
}

// Check if any errors occurred during the addition process
if (count($errors) === 0) {
    // All customers added successfully
    header("Location: admin.php");
} else {
    // Handle errors (you can display them or log them)
    foreach ($errors as $error) {
        echo $error . "<br>";
    }
}

// Close the database connection
$con->close();
?>




