<?php
include ('dbcon.php');

// Retrieve the list of usernames to remove and split them into an array
$usernames_to_remove = $_POST['usernames_to_remove'];
$usernames_array = explode(',', $usernames_to_remove);

// Initialize an array to store errors
$errors = [];

foreach ($usernames_array as $username) {
    // Remove any leading/trailing white spaces and sanitize the username
    $username = trim($username);
    $username = $con->real_escape_string($username);

    // Delete the user from the 'users' table
    $sql = "DELETE FROM users WHERE username = '$username'";

    if ($con->query($sql) !== TRUE) {
        // Error handling: If a username removal fails, add it to the errors array
        $errors[] = "Error removing user '$username': " . $con->error;
    }
}

// Check if any errors occurred during the removal process
if (count($errors) === 0) {
    // All users removed successfully
    header("Location: admin.php");
} else {
    // Handle errors (you can display them or log them)
    foreach ($errors as $error) {
        echo $error . "<br>";
    }
}

// Close the database connection
$con->close();
?>



