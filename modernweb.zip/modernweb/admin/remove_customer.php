<?php
include ('dbcon.php');

// Retrieve the list of usernames to remove and split them into an array
$names_to_remove = $_POST['names_to_remove'];
$names_array = explode(',', $names_to_remove);

// Initialize an array to store errors
$errors = [];

foreach ($names_array as $name) {
    // Remove any leading/trailing white spaces and sanitize the username
    $name = trim($name);
    $name = $con->real_escape_string($name);

    // Delete the user from the 'users' table
    $sql = "DELETE FROM customer WHERE name = '$name'";

    if ($con->query($sql) !== TRUE) {
        // Error handling: If a username removal fails, add it to the errors array
        $errors[] = "Error removing customer '$name': " . $con->error;
    }
}

// Check if any errors occurred during the removal process
if (count($errors) === 0) {
    // All users removed successfully
    header("Location: admin.php");
} else {
    // Handle errors (you can display them or log them)
    foreach ($errors as $error) {
        echo $error . "<br>";
    }
}

// Close the database connection
$con->close();
?>


