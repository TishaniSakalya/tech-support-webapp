<?php
include('dbcon.php');

// Retrieve the list of names to edit and split them into an array
$names_to_edit = explode(',', $_POST['names_to_edit']);
$contacts_to_edit = explode(',', $_POST['contacts_to_edit']);

// Initialize an array to store errors
$errors = [];

// Check if the number of names and contacts match
if (count($names_to_edit) !== count($contacts_to_edit)) {
    echo "The number of names and contacts must match.";
    exit;
}

for ($i = 0; $i < count($names_to_edit); $i++) {
    $name_to_edit = trim($names_to_edit[$i]);
    $contact_to_edit = trim($contacts_to_edit[$i]);

    $name_to_edit = $con->real_escape_string($name_to_edit);
    $contact_to_edit = $con->real_escape_string($contact_to_edit);

    // Update the contact for each customer in the 'customers' table
    $sql = "UPDATE customer SET contact = '$contact_to_edit' WHERE name = '$name_to_edit'";

    if ($con->query($sql) !== TRUE) {
        // Handle errors: If an error occurs while updating a customer, add it to the errors array
        $errors[] = "Error updating contact for customer '$name_to_edit': " . $con->error;
    }
}

// Check if any errors occurred during the editing process
if (count($errors) > 0) {
    // Handle errors (you can display them or log them)
    foreach ($errors as $error) {
        echo $error . "<br>";
    }
} else {
    // Editing was successful for all specified customers
    echo "Customers edited successfully.";
}

// Close the database connection
$con->close();
?>


