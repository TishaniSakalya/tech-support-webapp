<?php
include('dbcon.php');

// Retrieve the list of usernames to view and split them into an array
$usernames_to_view = explode(',', $_POST['usernames_to_view']);

// Initialize an array to store errors
$errors = [];

echo "<h2>Users List</h2>";
echo "<table border='1'>
        <tr>
            <th>Username</th>
            <th>Role</th>
        </tr>";

foreach ($usernames_to_view as $username) {
    // Remove any leading/trailing white spaces and sanitize the username
    $username = trim($username);
    $username = $con->real_escape_string($username);

    // Query to retrieve user data from the 'users' table
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $con->query($sql);

    if ($result->num_rows > 0) {
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["username"] . "</td>
                    <td>" . $row["role"] . "</td>
                </tr>";
        }
    } else {
        // Handle errors: If a user is not found, add it to the errors array
        $errors[] = "User '$username' not found.";
    }
}

echo "</table>";

// Check if any errors occurred during the viewing process
if (count($errors) > 0) {
    // Handle errors (you can display them or log them)
    foreach ($errors as $error) {
        echo $error . "<br>";
    }
}

// Close the database connection
$con->close();
?>


