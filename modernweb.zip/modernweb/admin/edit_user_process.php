<?php
include('dbcon.php');

// Retrieve the list of usernames to edit and split them into an array
$usernames_to_edit = explode(',', $_POST['usernames_to_edit']);
$new_usernames = explode(',', $_POST['new_usernames']);

// Initialize an array to store errors
$errors = [];

// Check if the number of usernames and roles match
if (count($usernames_to_edit) !== count($new_usernames)) {
    echo "The number of usernames and roles must match.";
    exit;
}

for ($i = 0; $i < count($usernames_to_edit); $i++) {
    $username_to_edit = trim($usernames_to_edit[$i]);
    $new_username = trim($new_usernames[$i]);

    $username_to_edit = $con->real_escape_string($username_to_edit);
    $new_username = $con->real_escape_string($new_username);

    // Update the role for each user in the 'users' table
    $sql = "UPDATE users SET username = '$new_username' WHERE username = '$username_to_edit'";

    if ($con->query($sql) !== TRUE) {
        // Handle errors: If an error occurs while updating a user, add it to the errors array
        $errors[] = "Error updating role for user '$username_to_edit': " . $conn->error;
    }
}

// Check if any errors occurred during the editing process
if (count($errors) > 0) {
    // Handle errors (you can display them or log them)
    foreach ($errors as $error) {
        echo $error . "<br>";
    }
} else {
    // Editing was successful for all specified users
    echo "Users edited successfully.";
}

// Close the database connection
$con->close();
?>


