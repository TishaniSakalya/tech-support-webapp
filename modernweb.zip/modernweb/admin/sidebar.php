<!DOCTYPE html>
<html>
<head>
    <style>

        .logout-button {
            position: fixed;
            top:8px;
            right: 8px;
            background-color: #007BFF;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        .logout-button a {
            text-decoration: none;
            color: white;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        .container {
            display: flex;
            height: 100vh;
        }

        .sidebar {
            width: 250px;
            background-color: #333;
            color: #fff;
            padding: 20px;
            height: 100%; 
        }

        .sidebar a {
            display: block;
            color: #fff;
            text-decoration: none;
            padding: 10px 0;
        }

        .dropdown-content {
            display: none;
            padding-left: 15px;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Style for section titles */
        .section-title {
            color: #007BFF;
            font-weight: bold;
        }

    </style>
</head>
<body>

    <div class="logout-button">
        <?php
         echo '<a href="../logout.php">Log Out</a>';
        ?>
    </div>

    <div class="container">
        <div class="sidebar">
            <div class="dropdown">
                <span class="section-title">
                    <a href="javascript:void(0);" onclick="toggleDropdown('userDropdown')">User Management</a>
                </span>

                <div class="dropdown-content" id="userDropdown">
                    <a href="add_user.html">Add User</a>
                    <a href="edit_user.html">Edit User</a>
                    <a href="remove_user.html">Remove User</a>
                    <a href="view_user.html">View User</a>
                </div>
            </div>
            <div class="dropdown">
                <span class="section-title">
                    <a href="javascript:void(0);" onclick="toggleDropdown('userDropdown')">Customer Management</a>
                </span>
                
                <div class="dropdown-content" id="userDropdown">
                    <a href="add_customer.html">Add Customer</a>
                    <a href="edit_customer.html">Edit Customer</a>
                    <a href="remove_customer.html">Remove Customer</a>
                    <a href="view_customer.html">View Customer</a>
                </div>
            </div>
            <div class="dropdown">
                <span class="section-title">
                    <a href="javascript:void(0);" onclick="toggleDropdown('userDropdown')">Service Provider Management</a>
                </span>
                
                <div class="dropdown-content" id="userDropdown">
                    <a href="add_service_provider.html">Add Service Provider</a>
                    <a href="edit_service_provider.html">Edit Service Provider</a>
                    <a href="remove_service_provider.html">Remove Service Provider</a>
                    <a href="view_service_provider.html">View Service Provider</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleDropdown(dropdownId) {
            var dropdown = document.getElementById(dropdownId);
            if (dropdown.style.display === 'block') {
                dropdown.style.display = 'none';
            } else {
                dropdown.style.display = 'block';
            }
        }
    </script>

</div>

    <!-- Footer -->
    <footer>
        <p>&copy; TechGeeks 2024. All Rights Reserved.</p>
    </footer>


</body>
</html>
