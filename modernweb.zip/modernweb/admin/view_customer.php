<?php
include('dbcon.php');

// Retrieve the list of names to view and split them into an array
$names_to_view = explode(',', $_POST['names_to_view']);

// Initialize an array to store errors
$errors = [];

echo "<h2>Customer List</h2>";
echo "<table border='1'>
        <tr>
            <th>Name</th>
            <th>Contact</th>
        </tr>";

foreach ($names_to_view as $name) {

    $name = trim($name);
    $name = $con->real_escape_string($name);

    // Query to retrieve customer data from the 'customers' table
    $sql = "SELECT name, contact FROM customer WHERE name = '$name'";
    $result = $con->query($sql);

    if ($result->num_rows > 0) {
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["name"] . "</td>
                    <td>" . $row["contact"] . "</td>
                </tr>";
        }
    } else {
        // Handle errors: If a customer is not found, add it to the errors array
        $errors[] = "Customer '$name' not found.";
    }
}

echo "</table>";

// Check if any errors occurred during the viewing process
if (count($errors) > 0) {
    // Handle errors (you can display them or log them)
    foreach ($errors as $error) {
        echo $error . "<br>";
    }
}

// Close the database connection
$con->close();
?>


