<?php

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydb";

$con = mysqli_connect("localhost","root","","mydb");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>


