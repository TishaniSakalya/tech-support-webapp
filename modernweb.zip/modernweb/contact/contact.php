<?php

include('dbcon.php');

// Get the form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $message = $_POST["message"];

    // Prepare and execute the SQL query to insert data into the "contact" table
    $sql = "INSERT INTO contact (name, email, message) VALUES ('$name','$email','$message')";

    // Execute the query
    if ($con->query($sql) === TRUE) {
        // After successful insertion, redirect to home page
        header("Location: ../home/user.php");
        exit; // Exit to prevent further execution
    } else {
        // Handle errors
        echo "Error: " . $sql . "<br>" . $con->error;
    }

    // Close the database connection
    $con->close();
    } else {
    // Handle the case when the form is not submitted
    echo "Form not submitted.";
    }
?>


