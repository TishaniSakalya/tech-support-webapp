<!DOCTYPE html>
<html>

<head>
    <title>Help</title>
    <style>
        body {
            background: url('tech5.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .faq-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            margin-top: 20px;
        }

        h1 {
            font-size: 36px;
            text-align: center;
            color: #2EA017;
            margin-bottom: 20px;
        }

        p {
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-size: 20px;
            margin-bottom: 10px;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            resize: vertical;
        }

        button {
            background-color: #D83C71;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
        }

        /* Style the navigation bar */
        .navbar {
            background-color: rgba(255, 255, 255, 0.6); /* Transparent black background */
            padding: 20px;
            display: flex;
            justify-content: space-between;
        }

        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .navbar li {
            display: inline;
            margin-right: 20px;
        }

        .navbar a {
            text-decoration: none;
            color: rgb(0, 0, 0); /* Text color for navigation links */
        }

        /* User section */
        .user-section {
            display: flex;
            align-items: center;
        }

        .user-options {
            display: flex;
            align-items: center;
        }

        .user-options a {
            color: #000000;
            text-decoration: none;
            margin-left: 20px;
        }

        /* Footer */
        footer {
            text-align: center;
            background: #333;
            padding: 10px 0;
        }

        footer p {
            color: #fff;
            font-size: 14px;
        }
    </style>
    <link rel="icon" type="image/x-icon" href="techgeek.png">
</head>

<body>

    <div class="navbar">
        <ul>
            <li><a href="../home/user.php">Home</a></li>
            <li><a href="../customer/customer.php">Services</a></li>
            <li><a href="../contact/contact.html">Contact</a></li>
            <li><a href="../help/help.php">Help</a></li>
        </ul>
        <div class="user-options">
            <a href="../logout.php">Log Out</a>
        </div>
    </div>

    <div class="faq-container">
        <h1>Frequently Asked Questions</h1>
            <div class="faq-item">
                <h2>  How do I find the login page? </h2>
                <p> You need to type localhost/modernweb to get to the login form .</p>
            </div>

            <div class="faq-item">
                <h2>  I didn't login. Can I visit your page? </h2>
                <p> Yes, all users who haven't logged in can visit our home page. </p>
            </div>

            <div class="faq-item">
                <h2>  Why does it say I am not allowed to enter this page? </h2>
                <p> Only logged in users are allowed to enter services page. </p>
            </div>

            <div class="faq-item">
                <h2>  How do I find a service provider? </h2>
                <p> You can find service providers on services page once you login. </p>
            </div>

        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; TechGeeks 2024. All Rights Reserved.</p>
    </footer>

</body>

</html>


