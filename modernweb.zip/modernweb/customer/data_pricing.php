<!DOCTYPE html>
<html>
<head>
    <title>Data Recovery Service Pricing</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="common1.css"> 
    <link rel="icon" type="image/x-icon" href="techgeek.png">
</head>
<body>

<?php
include('dbcon.php');

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["provider"])) {
    $providerName = $_GET["provider"];

    // Retrieve service pricing based on the provider name
    $sql = "SELECT service1, pricing1, service2, pricing2, service3, pricing3
            FROM data_support
            WHERE name = '$providerName'";

    $result = $con->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $service1 = $row['service1'];
        $pricing1 = $row['pricing1'];
        $service2 = $row['service2'];
        $pricing2 = $row['pricing2'];
        $service3 = $row['service3'];
        $pricing3 = $row['pricing3'];
?>

<div class="background-image">
        
    <div class="navbar">
        <ul>
            <li><a href="../home/user.php">Home</a></li>
            <li><a href="../customer/customer.php">Services</a></li>
            <li><a href="../contact/contact.html">Contact</a></li>
            <li><a href="../help/help.php">Help</a></li>
        </ul>
        <div class="user-options">
            <a href="../logout.php">Log Out</a>
        </div>
    </div>
    
        <div class="center-content">
            <div class="services">

                <h3>Service Provider: <?php echo $providerName; ?></h3>

                <!-- Include checkboxes for service selection -->
                <form action="payment.php" method="post" id="service-form">
                    <input type="hidden" name="provider" value="<?php echo $providerName; ?>">
                    <label for="service1">
                        <input type="checkbox" name="service1" id="service1" data-price="<?php echo $pricing1; ?>"> <?php echo $service1; ?> - $<?php echo $pricing1; ?>
                    </label><br>
                    <label for="service2">
                        <input type="checkbox" name="service2" id="service2" data-price="<?php echo $pricing2; ?>"> <?php echo $service2; ?> - $<?php echo $pricing2; ?>
                    </label><br>
                    <label for="service3">
                        <input type="checkbox" name="service3" id="service3" data-price="<?php echo $pricing3; ?>"> <?php echo $service3; ?> - $<?php echo $pricing3; ?>
                    </label><br>

                    <button type="button" id="pay-now">Pay Now</button>
                </form>
            </div>
        </div>
</div>

<?php
    } else {
        echo "Provider not found. Please go back and select a valid provider.";
    }
} else {
    echo "Invalid request. Please go back and select a provider.";
}
?>

<script>
document.getElementById("pay-now").addEventListener("click", function() {
    // Calculate the total price as you did before
    const checkboxes = document.querySelectorAll("input[type='checkbox']");
    let totalPrice = 0;

    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            const price = parseFloat(checkbox.dataset.price);
            totalPrice += price;
        }
    });

    // Redirect to payment page with total price and selected services
    window.location.href = `payment.php?totalPrice=${totalPrice}&provider=<?php echo $providerName; ?>`;
});
</script>

</body>
</html>

