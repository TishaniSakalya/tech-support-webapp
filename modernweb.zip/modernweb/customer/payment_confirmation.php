<!DOCTYPE html>
<html>
<head>
    <title>Thank You Customer</title>
    <style> 
    .background-image {
            background-image: url('tech5.jpg');
            background-size: cover;
            background-position: center;
            min-height: 100vh;
            position: relative;
            color: #fff;
            text-align: center; 
    }

        /* Style the navigation bar */
        .navbar {
        background-color: rgba(255, 255, 255, 0.6); /* Transparent black background */
        padding: 20px;
        display: flex;
        justify-content: space-between;
    }

    .navbar ul {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    .navbar li {
        display: inline;
        margin-right: 20px;
    }

    .navbar a {
        text-decoration: none;
        color: rgb(0, 0, 0); /* Text color for navigation links */
    }

    /* User section */
    .user-section {
        display: flex;
        align-items: center;
    }

    .user-options {
        display: flex;
        align-items: center;
    }

    .user-options a {
        color: #000000;
        text-decoration: none;
        margin-left: 20px;
    }
    </style>
    <link rel="icon" type="image/x-icon" href="techgeek.png">
</head>
<body>
<div class="background-image">
    <div class="navbar">
        <ul>
            <li><a href="../home/user.php">Home</a></li>
            <li><a href="../customer/customer.php">Services</a></li>
            <li><a href="../contact/contact.html">Contact</a></li>
            <li><a href="../help/help.php">Help</a></li>
        </ul>
        <div class="user-options">
            <a href="../logout.php">Log Out</a>
        </div>
    </div>

    <?php
    include('../session.php');

    // Now you can access the user_name
    $user_name = $_SESSION['user_name'];

    ?>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        include('dbcon.php'); 

        // Sanitize and validate input
        $totalPrice = $_POST['totalPrice'];
        $username = $_POST['username'];

        // Check if the username exists in the database
        $checkUserQuery = "SELECT * FROM users WHERE username = '$username'";
        $result = $con->query($checkUserQuery);

        if ($result->num_rows > 0) {
            // Username exists, proceed with payment
            // Insert the payment details into the "payment" table
            $insertQuery = "INSERT INTO payment (name, payment) VALUES ('$username', $totalPrice)";

            if ($con->query($insertQuery) === TRUE) {
                echo "<script type='text/javascript'>alert('Thank You customer $user_name, for your payment!');</script>";
            } else {
                echo "<script type='text/javascript'>alert('Error: $con->error');</script>";
            }
        } else {
            // Username does not exist, display error message
            echo "<script type='text/javascript'>alert('Error: Username not found in the database.');</script>";
        }
    } else {
        echo "Invalid request. Please go back and enter your details.";
    }
    ?>
</div>
</body>
</html>
