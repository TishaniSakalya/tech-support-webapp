<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css"> 
    <link rel="icon" type="image/x-icon" href="techgeek.png">
    <title>TechGeeks</title>
</head>
<body>
    <div class="background-image">
    <div class="navbar">
        <ul>
            <li><a href="../home/user.php">Home</a></li>
            <li><a href="../customer/customer.php">Services</a></li>
            <li><a href="../contact/contact.html">Contact</a></li>
            <li><a href="../help/help.php">Help</a></li>
        </ul>
        <div class="user-options">
            <a href="../logout.php">Log Out</a>
        </div>
    </div>
        <div class="services">
            <?php
            include('dbcon.php');
            $sql = "SELECT name, service1, description1, pricing1, service2, description2, pricing2, service3, description3, pricing3 FROM network";
            $result = $con->query($sql);

            while ($row = $result->fetch_assoc()) {
                // Fetch data from the row
                $name = $row['name'];
                $service1 = $row['service1'];
                $description1 = $row['description1'];
                $pricing1 = $row['pricing1'];
                $service2 = $row['service2'];
                $description2 = $row['description2'];
                $pricing2 = $row['pricing2'];
                $service3 = $row['service3'];
                $description3 = $row['description3'];
                $pricing3 = $row['pricing3'];
            ?>
                <div class="service-card">
                    <div class="service-info">
                        <h2><?php echo $name; ?></h2>
                        <p>
                            <strong><?php echo $service1; ?></strong>: <?php echo $description1; ?><br>
                            <strong>Pricing:</strong> <?php echo $pricing1; ?><br>
                            <strong><?php echo $service2; ?></strong>: <?php echo $description2; ?><br>
                            <strong>Pricing:</strong> <?php echo $pricing2; ?><br>
                            <strong><?php echo $service3; ?></strong>: <?php echo $description3; ?><br>
                            <strong>Pricing:</strong> <?php echo $pricing3; ?><br>
                        </p>
                        <div class="link">
                            <a href="network_pricing.php?provider=<?php echo $name; ?>">Accept Offer</a>
                        </div>
                    </div>
                </div>
            <?php
            }
            $con->close();
            ?>
        </div>

    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; TechGeeks 2024. All Rights Reserved.</p>
    </footer>

    <script>
    // Add a click event listener to all "Accept Offer" buttons
    const acceptOfferButtons = document.querySelectorAll('.card__apply a');
    acceptOfferButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            // Prevent the default link behavior
            event.preventDefault();

            // Get the provider name from the "href" attribute
            const providerName = this.getAttribute('href').split('=')[1];

            // Redirect to "software_pricing.php" with the provider name as a query parameter
            window.location.href = `network_pricing.php?provider=${providerName}`;
        });
    });

    </script>

</body>
</html>
