<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="common.css"> 
    <link rel="icon" type="image/x-icon" href="techgeek.png">
    <title>TechGeeks</title>
    <!-- Include jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        /* Define the CSS for the element to be animated */
        .service-card {
            display: inline-block;
            vertical-align: top;
            width: 200px;
            margin: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
            background-color: #fff;
        }
        
        .service-card:hover {
            transform: scale(1.05);
        }
        
        .service-card img {
            max-width: 100%;
            height: auto;
        }
        
        .service-info {
            display: none;
        }
        
        /* Highlight the current location in the navigation bar */
        .navbar ul li.current a {
            font-weight: bold;
        }
    </style>
</head>
<body>

    <?php
    session_start(); // Make sure to start the session

    $user_name = $_SESSION['user_name'];

    if (empty($user_name)) {
        // If user_name is empty
        echo '<script>alert("Access denied. You do not have permission to access this page.");</script>';
        exit; // Stop further execution of the script
    }

    ?>

    <script type="text/javascript">
        // Display a pop-up message
        alert("Welcome customer <?php echo $_SESSION['user_name']; ?>!");
    </script>

    <div class="background-image">
        
    <div class="navbar">
            <ul>
                <li><a href="../home/user.php">Home</a></li>
                <li class="current"><a href="../customer/customer.php">Services</a></li>
                <li><a href="../contact/contact.html">Contact</a></li>
                <li><a href="../help/help.php">Help</a></li>
            </ul>
            <div class="user-section">
                <a href="../logout.php" class="registration-button">Log Out</a>
            </div>
    </div>
        
        <div class="center-content">
            <div class="services">
                <div class="service-card">
                    <a href="software_support.php">
                        <img src="./img/service1.jpg" alt="Service 1">
                    </a>
                    
                    <div class="service-info">
                        <h2>Software Support</h2>
                        <p>Our experts provide assistance with software-related issues, from troubleshooting errors to optimizing system performance.</p>
                    </div>
                </div>

                <div class="service-card">
                    <a href="hardware_support.php"> 
                        <img src="./img/service2.jpg" alt="Service 2">
                    </a>
                    
                    <div class="service-info">
                        <h2>Hardware Support</h2>
                        <p>Get reliable help with hardware malfunctions, upgrades, and maintenance to ensure your equipment runs smoothly.</p>
                    </div>
                </div>

                <div class="service-card">
                    <a href="network_support.php">
                        <img src="./img/service3.jpg" alt="Service 3"> 
                    </a>
                    
                    <div class="service-info">
                        <h2>Network Support</h2>
                        <p>We offer network solutions for seamless connectivity, including setup, maintenance, and troubleshooting to keep your business connected.</p>
                    </div>
                </div>

                <div class="service-card">
                    <a href="data_support.php">
                        <img src="./img/service4.jpg" alt="Service 4">
                    </a>
                    
                    <div class="service-info">
                        <h2>Data recovery services</h2>
                        <p>When data loss occurs, our specialists are here to help recover your important files and ensure minimal disruption to your operations.</p>
                    </div>
                </div>

                <div class="service-card">
                    <a href="cyber_support.php">
                        <img src="./img/service5.jpg" alt="Service 5">
                    </a>
                    
                    <div class="service-info">
                        <h2>Cybersecurity services</h2>
                        <p>Protect your valuable data with our cutting-edge cybersecurity services, safeguarding your business against digital threats and ensuring data integrity.</p>
                    </div>
                </div>
            </div>
            
        </div>

           
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; TechGeeks 2024. All Rights Reserved.</p>
    </footer>

    <script>
        // jQuery code for animation
        $(document).ready(function() {
            // Add animation to service cards on hover
            $('.service-card').hover(function() {
                $(this).find('.service-info').slideDown();
            }, function() {
                $(this).find('.service-info').slideUp();
            });
        });
    </script>
</body>
</html>


